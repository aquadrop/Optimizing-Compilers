void main()
{      
	int a = 0;
	int i =0;
	for (i = 0; i<3; i++)
	{
		a = 3;
	}
}
