/* Generated automatically by the SUIF makefiles. */

char *prog_ver_string = "(unnumbered test version)";
char *prog_who_string = "compiled Mon Apr 29 09:54:13 EDT 2013 by xujianwe on ug52.eecg";
char *prog_suif_string = "1.1.2";
