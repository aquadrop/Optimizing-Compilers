void main()
{
	int i = 0;
	int a = 1;
	for (i = 0; i<3; i++){
	int b = 3;        
	a = b + a;
	if (a>3)
		a = 1;
        }
}
